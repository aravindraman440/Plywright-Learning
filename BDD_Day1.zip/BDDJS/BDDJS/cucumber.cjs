module.exports = {
    default: {
      import: ["./src/tests/steps/"],
      format: ["progress-bar"],
    }
  };
  