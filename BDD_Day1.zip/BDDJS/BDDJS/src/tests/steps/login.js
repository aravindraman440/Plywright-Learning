import { Given, When, Then } from '@cucumber/cucumber';
import { chromium} from '@playwright/test';

let browser, page;

         Given('Load the url', async function () {
           browser = await chromium.launch({headless:false});
           page = await browser.newPage();
           await page.goto('http://www.saucedemo.com/');
         });
         Given('Enter valid username and password', async function () {
          await page.fill('#user-name','standard_user');
          await page.fill('#password','secret_sauce');
          
         });
         When('Clicked on Login button', async function () {
          await page.click('#login-button');
         });
         Then('User should be able to login successfully', async function () {
          await browser.close();
        });
         