const { Before, After, AfterAll, BeforeAll, setWorldConstructor } = require('@cucumber/cucumber');
const { pageFixture } = require('./pageFixture');

class CustomWorld {
  constructor() {
    this.page = null;
  }
}

setWorldConstructor(CustomWorld);

BeforeAll(async () => {
  await pageFixture.init();
});

Before(async function () {
  this.page = pageFixture.page;
});

After(async function () {
  // You can take screenshots here if needed
  if (this.page) {
    await this.page.screenshot({ path: `reports/${Date.now()}.png` });
  }
});

AfterAll(async () => {
  await pageFixture.close();
});
