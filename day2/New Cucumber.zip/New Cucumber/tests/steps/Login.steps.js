const { Given, When, Then } = require('@cucumber/cucumber');
const { LoginPage } = require('../pages/LoginPage');

let loginPage;

Given('Load the url', async function () {
  loginPage = new LoginPage(this.page);
  await loginPage.navigate();
});

When('I login with {string} and {string}', async function (username, password) {
  await loginPage.login(username, password);
});

Then('Clicked on Login button', async function () {
     
  await loginPage.clickLoginButton() ;

});
