const { Given, When, Then } = require('@cucumber/cucumber');
const { CreateLeadPage } = require('../pages/CreateLeadPage');
const { LoginPage } = require('../pages/LoginPage');

let createLeadPage;

When('Click crmsfa hyper link', async function () {
    createLeadPage = new CreateLeadPage(this.page);
    await createLeadPage.clickCrmsfaLink();
    
   });

   When('Click leads tap', async function () {
    await createLeadPage.clickLeadtap();
    });
    When('Click on createLead button', async function () {
        await createLeadPage.clickCreateLeadButton();
    });
    When('Enter the first name', async function () {
        await createLeadPage.enterFirstName();
    });
    When('Enter the last name', async function () {
        await createLeadPage.enterLastName();
    });
    When('Enter the company name', async function () {
        await createLeadPage.enterCompanyName();
    });
   // await page.waitForTimeout(5000);
    When('click on submit button', async function () {
        
     const submitButton = await createLeadPage.clickSubmitButton();

     // Ensure the button is visible and enabled before clicking
     await submitButton.waitFor({ state: 'visible' }); // Wait for the button to be visible
     await submitButton.scrollIntoViewIfNeeded(); // Scroll if needed
     await submitButton.click(); 
    // await page.locator('.submitButton').waitFor();
    //to scroll the visibility of an element
   //  await page.locator('.submitButton').scrollIntoViewIfNeeded();
    //  await page.click('[name="submitButton"]')

    });
    When('The lead create successfully', async function () {
     let title = await this.page.title();
    // console.log('Page title:', title);
     console.log('📄 Page title:', title);
    });
