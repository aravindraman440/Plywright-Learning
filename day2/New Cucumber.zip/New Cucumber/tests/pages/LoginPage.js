


class LoginPage {
    constructor(page) {
      this.page = page;
      this.usernameInput = 'id=username';
      this.passwordInput = 'id=password';
      this.loginButton = '.decorativeSubmit';
      
    }
  
    async navigate() {
      await this.page.goto('http://leaftaps.com/opentaps/control/main');
    }
  
    async login(username, password) {
      await this.page.fill(this.usernameInput, username);
      await this.page.fill(this.passwordInput, password);
      
    }
  
    async clickLoginButton() {
        await this.page.click(this.loginButton);
      //return this.page.isVisible(this.dashboardSelector);
    }
    
  }
  
  module.exports = { LoginPage };