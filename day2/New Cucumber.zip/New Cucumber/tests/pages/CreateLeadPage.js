

class CreateLeadPage {
    constructor(page) {
      this.page = page;
      this.crmsfaLink = '//a[normalize-space()="CRM/SFA"]';
      this.leadsTap = 'text="Leads"';
      this.createLeadButton = 'text="Create Lead"';
      this.firstName = 'id=createLeadForm_firstName';
      this.lastName = 'id=createLeadForm_lastName';
      this.companyName = 'id=createLeadForm_companyName';
      this.submiButton = '[name="submitButton"]';
    }
  
    async clickCrmsfaLink() {
        console.log('Selector:', this.crmsfaLink); 
        await this.page.waitForSelector(this.crmsfaLink, { timeout: 10000 }); // Wait up to 10 seconds
        await this.page.click(this.crmLink);
        console.log("Clicked CRM/SFA link.");
     // await this.page.click(this.crmsfaLink);
    }

    async clickLeadTap () {
        await this.page.click(this.leadsTap)
   };
    async clickCreateLeadButton () {
         await this.page.click(this.createLeadButton)
     };
    async enterFirstName () {
         await this.page.click(this.firstName)
        };
     async enterLastName () {
         await this.page.fill(this.lastName)
        };
     async enterCompanyName () {
         await this.page.fill(companyName)
        };
     async clickSubmiButton () {
         await this.page.fill(this.submiButton)
        };
    async verifyTitle () {
         let title = await this.page.title();
        // console.log('Page title:', title);
         console.log('📄 Page title:', title);
        };
  }
  
  module.exports = { CreateLeadPage };