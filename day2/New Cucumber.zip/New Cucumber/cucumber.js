module.exports = {
    default: {
      require: ['tests/steps/*.js', 'tests/support/*.js'],
      format: ['progress', 'json:reports/cucumber_report.json'],
      paths: ['tests/features/createLead.feature'],
     // parallel: 1, // Set to more than 1 for parallel execution
      worldParameters: {},
    },
  };